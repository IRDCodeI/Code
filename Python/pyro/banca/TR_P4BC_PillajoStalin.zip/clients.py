class Client:
    
    account = ''
    credit = 0
    
    def __init__(self, account, credit) -> None:
        self.account = account
        self.credit = credit

